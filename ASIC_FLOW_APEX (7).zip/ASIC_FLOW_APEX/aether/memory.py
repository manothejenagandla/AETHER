"""Simple memory pool for buffer reuse"""
from __future__ import annotations
import threading
from typing import Dict, List, Tuple
import numpy as np

class MemoryPool:
    def __init__(self):
        self._pools: Dict[Tuple[tuple, str], List[np.ndarray]] = {}
        self._lock = threading.Lock()
        self.stats = {"allocs": 0, "reuses": 0, "releases": 0}

    def acquire(self, shape, dtype=np.float32) -> np.ndarray:
        key = (tuple(shape) if not isinstance(shape, tuple) else shape, np.dtype(dtype).str)
        with self._lock:
            bucket = self._pools.setdefault(key, [])
            if bucket:
                self.stats["reuses"] += 1
                return bucket.pop()
            self.stats["allocs"] += 1
            return np.empty(shape, dtype=dtype)

    def release(self, arr: np.ndarray):
        if arr is None:
            return
        key = (arr.shape, arr.dtype.str)
        with self._lock:
            self._pools.setdefault(key, []).append(arr)
            self.stats["releases"] += 1

    def clear(self):
        with self._lock:
            self._pools.clear()

_global_pool = MemoryPool()

def get_pool() -> MemoryPool:
    return _global_pool
