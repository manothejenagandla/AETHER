"""Simple profiler / benchmark helpers"""
from __future__ import annotations
import time
from typing import Callable, Dict, Any
from contextlib import contextmanager

class ProfileResult:
    def __init__(self, name: str):
        self.name = name
        self.samples_ms: list = []

    def add(self, ms: float):
        self.samples_ms.append(ms)

    def summary(self) -> Dict[str, Any]:
        if not self.samples_ms:
            return {"name": self.name, "n": 0}
        arr = self.samples_ms
        return {
            "name": self.name,
            "n": len(arr),
            "mean_ms": sum(arr) / len(arr),
            "min_ms": min(arr),
            "max_ms": max(arr),
            "total_ms": sum(arr),
        }

class Profiler:
    def __init__(self):
        self.results: Dict[str, ProfileResult] = {}

    @contextmanager
    def measure(self, name: str):
        t0 = time.perf_counter()
        yield
        ms = (time.perf_counter() - t0) * 1000
        if name not in self.results:
            self.results[name] = ProfileResult(name)
        self.results[name].add(ms)

    def report(self) -> Dict[str, dict]:
        return {k: v.summary() for k, v in self.results.items()}

    def print_report(self):
        print("AETHER Profile Report")
        print("-" * 40)
        for name, s in self.report().items():
            if s["n"] == 0:
                continue
            print(f"  {name}: mean={s['mean_ms']:.2f} ms  min={s['min_ms']:.2f}  max={s['max_ms']:.2f}  n={s['n']}")

def benchmark(fn: Callable, warmup: int = 2, repeats: int = 5, name: str = "bench") -> dict:
    for _ in range(warmup):
        fn()
    samples = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - t0) * 1000)
    return {
        "name": name,
        "mean_ms": sum(samples) / len(samples),
        "min_ms": min(samples),
        "max_ms": max(samples),
        "samples": samples,
    }
