"""Real fusion + optional memory-pool intermediates for unfused path"""
from __future__ import annotations
from typing import Optional
import numpy as np
from .backends.cpu_native import NativeCPUBackend
from .memory import get_pool

def fuse_scale_add_scalar(backend: NativeCPUBackend, data: np.ndarray,
                          scale: float, bias: float, out: Optional[np.ndarray] = None) -> np.ndarray:
    """Single native pass: out = data * scale + bias"""
    return backend.scale_bias(data, scale, bias, out=out)

def unfused_scale_add_scalar(backend: NativeCPUBackend, data: np.ndarray,
                             scale: float, bias: float, use_pool: bool = True) -> np.ndarray:
    """Two launches; intermediate from pool when use_pool=True"""
    pool = get_pool()
    if use_pool:
        tmp = pool.acquire(data.shape, data.dtype)
        try:
            backend.scale(data, scale, out=tmp)
            out = backend.add_scalar(tmp, bias)
        finally:
            pool.release(tmp)
        return out
    tmp = backend.scale(data, scale)
    return backend.add_scalar(tmp, bias)
