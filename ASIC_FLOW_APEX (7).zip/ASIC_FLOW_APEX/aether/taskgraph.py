"""
AETHER Task Graph – concurrent execution including native CPU kernels
"""
from __future__ import annotations
from typing import Callable, List, Dict, Any, Optional, Union
from .scheduler import WorkStealingScheduler
import threading
import time

class TaskNode:
    def __init__(self, name: str, fn: Callable, args=(), kwargs=None):
        self.name = name
        self.fn = fn
        self.args = args
        self.kwargs = kwargs or {}
        self.deps: List[str] = []
        self.dependents: List[str] = []
        self.done = False
        self.result = None
        self.exception = None

class TaskGraph:
    def __init__(self, name: str = "graph"):
        self.name = name
        self.nodes: Dict[str, TaskNode] = {}

    def add(self, name: str, fn: Callable, args=(), kwargs=None, depends_on: Optional[List[str]] = None):
        node = TaskNode(name, fn, args, kwargs)
        if depends_on:
            for d in depends_on:
                if d not in self.nodes:
                    raise ValueError(f"Unknown dependency: {d}")
                node.deps.append(d)
                self.nodes[d].dependents.append(name)
        self.nodes[name] = node
        return self

    def add_native(self, name: str, backend, op: str, *args, depends_on=None, **kwargs):
        """
        Add a node that runs a NativeCPUBackend operation.
        op: 'vector_add' | 'scale' | 'scale_bias' | 'saxpy' | 'reduce_sum' | ...
        """
        def runner():
            method = getattr(backend, op)
            return method(*args, **kwargs)
        return self.add(name, runner, depends_on=depends_on)

    def execute(self, n_workers: Optional[int] = None) -> Dict[str, Any]:
        sched = WorkStealingScheduler(n_workers)
        sched.start()
        remaining = set(self.nodes.keys())
        lock = threading.Lock()

        def try_submit_ready():
            ready = []
            with lock:
                for name in list(remaining):
                    node = self.nodes[name]
                    if all(self.nodes[d].done for d in node.deps):
                        ready.append(name)
                for name in ready:
                    remaining.discard(name)
            for name in ready:
                node = self.nodes[name]
                def make_runner(n=node):
                    def runner():
                        try:
                            n.result = n.fn(*n.args, **n.kwargs)
                        except Exception as e:
                            n.exception = e
                        n.done = True
                        try_submit_ready()
                    return runner
                sched.submit(make_runner())

        try_submit_ready()
        deadline = time.time() + 180
        while remaining and time.time() < deadline:
            time.sleep(0.001)
            with lock:
                if not remaining:
                    break
        sched.wait(timeout=60)
        metrics = sched.metrics.to_dict()
        sched.shutdown()
        for name, node in self.nodes.items():
            if node.exception:
                raise node.exception
        return {name: node.result for name, node in self.nodes.items()}, metrics
