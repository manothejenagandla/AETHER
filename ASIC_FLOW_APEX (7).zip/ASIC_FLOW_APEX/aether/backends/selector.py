"""Backend selection – CPU-only AETHER"""
from .cpu_native import NativeCPUBackend, is_native_cpu_available
from .rtl_backend import RTLBackend

def get_backend(name: str = "cpu", **kwargs):
    name = name.lower().strip()
    if name in ("cpu", "cpu_native", "native"):
        if not is_native_cpu_available():
            raise RuntimeError("Native CPU library not found")
        return NativeCPUBackend(**kwargs)
    if name == "rtl":
        return RTLBackend(**kwargs)
    raise ValueError(f"Unknown backend '{name}'. Available: cpu, rtl")

def list_backends():
    return {
        "cpu_native": {
            "available": is_native_cpu_available(),
            "description": "Compiled C++ multi-core backend (OpenMP / std::thread)",
        },
        "rtl": {
            "available": True,
            "description": "SystemVerilog generator for supported kernel subset",
        },
    }
