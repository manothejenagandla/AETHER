"""AETHER Native CPU Backend v2.3"""
from __future__ import annotations
import ctypes
import pathlib
import os
import platform
from typing import Optional, Dict, Any
import numpy as np

_LIB = None
_LIB_PATH = None
_BUILD_FLAGS = "unknown"

def _find_lib():
    here = pathlib.Path(__file__).resolve().parent
    for p in [
        here.parent.parent / "native" / "libaether_cpu.so",
        pathlib.Path("native/libaether_cpu.so"),
    ]:
        if p.exists():
            return p
    return None

def is_native_cpu_available() -> bool:
    return _find_lib() is not None

def _load():
    global _LIB, _LIB_PATH
    if _LIB is not None:
        return _LIB
    path = _find_lib()
    if path is None:
        raise RuntimeError("libaether_cpu.so not found. Run native/build.sh")
    _LIB_PATH = path
    lib = ctypes.CDLL(str(path))

    def bin3(name):
        f = getattr(lib, name)
        f.argtypes = [ctypes.POINTER(ctypes.c_float)]*3 + [ctypes.c_int64, ctypes.c_int]
        f.restype = None
    bin3("aether_cpu_vector_add_f32")
    bin3("aether_cpu_vector_mul_f32")

    lib.aether_cpu_vector_add_f32_chunked.argtypes = [
        ctypes.POINTER(ctypes.c_float)]*3 + [ctypes.c_int64, ctypes.c_int, ctypes.c_int64]
    lib.aether_cpu_vector_add_f32_chunked.restype = None

    for name in ("aether_cpu_scale_f32", "aether_cpu_add_scalar_f32"):
        f = getattr(lib, name)
        f.argtypes = [ctypes.POINTER(ctypes.c_float)]*2 + [ctypes.c_float, ctypes.c_int64, ctypes.c_int]
        f.restype = None

    lib.aether_cpu_saxpy_f32.argtypes = [ctypes.c_float, ctypes.POINTER(ctypes.c_float),
        ctypes.POINTER(ctypes.c_float), ctypes.c_int64, ctypes.c_int]
    lib.aether_cpu_saxpy_f32.restype = None

    lib.aether_cpu_scale_bias_f32.argtypes = [
        ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
        ctypes.c_float, ctypes.c_float, ctypes.c_int64, ctypes.c_int]
    lib.aether_cpu_scale_bias_f32.restype = None

    for name in ("aether_cpu_reduce_sum_f32", "aether_cpu_reduce_max_f32", "aether_cpu_reduce_min_f32"):
        f = getattr(lib, name)
        f.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.c_int64, ctypes.c_int]
        f.restype = ctypes.c_float

    for name in ("aether_cpu_inclusive_scan_f32", "aether_cpu_exclusive_scan_f32"):
        f = getattr(lib, name)
        f.argtypes = [ctypes.POINTER(ctypes.c_float)]*2 + [ctypes.c_int64, ctypes.c_int]
        f.restype = None

    # Proper atomics
    lib.aether_cpu_atomic_i32_create.argtypes = [ctypes.c_int32]
    lib.aether_cpu_atomic_i32_create.restype = ctypes.c_void_p
    lib.aether_cpu_atomic_i32_destroy.argtypes = [ctypes.c_void_p]
    lib.aether_cpu_atomic_i32_add.argtypes = [ctypes.c_void_p, ctypes.c_int32]
    lib.aether_cpu_atomic_i32_add.restype = ctypes.c_int32
    lib.aether_cpu_atomic_i32_load.argtypes = [ctypes.c_void_p]
    lib.aether_cpu_atomic_i32_load.restype = ctypes.c_int32

    lib.aether_cpu_hardware_concurrency.restype = ctypes.c_int
    lib.aether_cpu_has_openmp.restype = ctypes.c_int

    _LIB = lib
    return lib


def detect_topology() -> Dict[str, Any]:
    info = {
        "architecture": platform.machine(),
        "logical_cpus": os.cpu_count() or 1,
        "physical_cores": None,
        "has_openmp": False,
        "simd": [],
    }
    try:
        with open("/proc/cpuinfo") as f:
            text = f.read().lower()
        for flag in ("avx512", "avx2", "avx", "sse4"):
            if flag in text:
                info["simd"].append(flag.upper())
        physical = set()
        with open("/proc/cpuinfo") as f:
            phys = core = None
            for line in f:
                if line.startswith("physical id"):
                    phys = line.split(":")[1].strip()
                elif line.startswith("core id"):
                    core = line.split(":")[1].strip()
                elif line.strip() == "":
                    if phys is not None and core is not None:
                        physical.add((phys, core))
                    phys = core = None
        if physical:
            info["physical_cores"] = len(physical)
    except Exception:
        pass
    if info["physical_cores"] is None:
        info["physical_cores"] = info["logical_cpus"]
    try:
        info["has_openmp"] = bool(_load().aether_cpu_has_openmp())
    except Exception:
        pass
    return info


class NativeAtomicI32:
    """Standards-correct integer atomic backed by C++ std::atomic."""
    def __init__(self, initial: int = 0):
        self._lib = _load()
        self._ptr = self._lib.aether_cpu_atomic_i32_create(int(initial))
    def add(self, v: int) -> int:
        return self._lib.aether_cpu_atomic_i32_add(self._ptr, int(v))
    def load(self) -> int:
        return self._lib.aether_cpu_atomic_i32_load(self._ptr)
    def __del__(self):
        try:
            if getattr(self, "_ptr", None):
                self._lib.aether_cpu_atomic_i32_destroy(self._ptr)
        except Exception:
            pass


class NativeCPUBackend:
    def __init__(self, n_threads: Optional[int] = None, chunk_size: Optional[int] = None):
        self.lib = _load()
        self.n_threads = n_threads or self.lib.aether_cpu_hardware_concurrency()
        self.chunk_size = chunk_size  # None = auto
        self.has_openmp = bool(self.lib.aether_cpu_has_openmp())
        self.kernel_launches = 0  # for fusion tests

    def info(self) -> dict:
        return {
            "backend": "cpu_native",
            "version": "2.3",
            "n_threads": self.n_threads,
            "chunk_size": self.chunk_size,
            "has_openmp": self.has_openmp,
            "library": str(_LIB_PATH),
            "topology": detect_topology(),
        }

    def _f32(self, a):
        return np.ascontiguousarray(a, dtype=np.float32)

    def _ptr(self, a):
        return a.ctypes.data_as(ctypes.POINTER(ctypes.c_float))

    def vector_add(self, A, B, out=None):
        A, B = self._f32(A), self._f32(B)
        if out is None: out = np.empty_like(A)
        else: out = self._f32(out)
        self.kernel_launches += 1
        if self.chunk_size and self.chunk_size > 0:
            self.lib.aether_cpu_vector_add_f32_chunked(
                self._ptr(A), self._ptr(B), self._ptr(out),
                A.size, self.n_threads, int(self.chunk_size))
        else:
            self.lib.aether_cpu_vector_add_f32(
                self._ptr(A), self._ptr(B), self._ptr(out), A.size, self.n_threads)
        return out

    def vector_mul(self, A, B, out=None):
        A, B = self._f32(A), self._f32(B)
        if out is None: out = np.empty_like(A)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_vector_mul_f32(self._ptr(A), self._ptr(B), self._ptr(out), A.size, self.n_threads)
        return out

    def saxpy(self, a, X, Y):
        X, Y = self._f32(X), self._f32(Y)
        self.kernel_launches += 1
        self.lib.aether_cpu_saxpy_f32(float(a), self._ptr(X), self._ptr(Y), X.size, self.n_threads)
        return Y

    def scale(self, In, factor, out=None):
        In = self._f32(In)
        if out is None: out = np.empty_like(In)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_scale_f32(self._ptr(In), self._ptr(out), float(factor), In.size, self.n_threads)
        return out

    def add_scalar(self, In, s, out=None):
        In = self._f32(In)
        if out is None: out = np.empty_like(In)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_add_scalar_f32(self._ptr(In), self._ptr(out), float(s), In.size, self.n_threads)
        return out

    def scale_bias(self, A, scale, bias, out=None):
        """Fused: Out = A * scale + bias  (single pass)"""
        A = self._f32(A)
        if out is None: out = np.empty_like(A)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_scale_bias_f32(
            self._ptr(A), self._ptr(out), float(scale), float(bias), A.size, self.n_threads)
        return out

    def reduce_sum(self, data):
        data = self._f32(data)
        self.kernel_launches += 1
        return float(self.lib.aether_cpu_reduce_sum_f32(self._ptr(data), data.size, self.n_threads))

    def reduce_max(self, data):
        data = self._f32(data)
        return float(self.lib.aether_cpu_reduce_max_f32(self._ptr(data), data.size, self.n_threads))

    def reduce_min(self, data):
        data = self._f32(data)
        return float(self.lib.aether_cpu_reduce_min_f32(self._ptr(data), data.size, self.n_threads))

    def inclusive_scan(self, data, out=None):
        data = self._f32(data)
        if out is None: out = np.empty_like(data)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_inclusive_scan_f32(self._ptr(data), self._ptr(out), data.size, self.n_threads)
        return out

    def exclusive_scan(self, data, out=None):
        data = self._f32(data)
        if out is None: out = np.empty_like(data)
        else: out = self._f32(out)
        self.kernel_launches += 1
        self.lib.aether_cpu_exclusive_scan_f32(self._ptr(data), self._ptr(out), data.size, self.n_threads)
        return out
