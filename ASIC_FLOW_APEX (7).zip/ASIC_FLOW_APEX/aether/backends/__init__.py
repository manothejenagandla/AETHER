"""AETHER Backends – CPU-only"""
from .cpu_native import NativeCPUBackend, is_native_cpu_available
from .rtl_backend import RTLBackend, SUPPORTED_KERNELS

def generate_rtl_stub(kernel_fn, module_name="aether_kernel"):
    """Compatibility wrapper – generates real SystemVerilog for known names."""
    be = RTLBackend(output_dir="rtl_out")
    name = getattr(kernel_fn, "__name__", "kernel")
    # Map common names
    key = "vector_add" if "add" in name else ("saxpy" if "saxpy" in name else "scale")
    return be.generate(key, module_name=module_name).read_text()


__all__ = [
    "NativeCPUBackend", "is_native_cpu_available",
    "RTLBackend",
]
