"""AETHER CPU Parallel Runtime v2.3"""
from .core import (
    kernel, cascade, launch, submit, dim3,
    threadIdx, blockIdx, blockDim, gridDim,
    shared, local, syncthreads,
    atomicAdd, atomicMax, atomicMin,
    DeviceArray, to_device, to_host,
    calculate_grid, calculate_grid_2d,
    Timer, ParallelContext, get_context,
    map_parallel, reduce, scan, shutdown,
)
from .backends import NativeCPUBackend, is_native_cpu_available, RTLBackend
from .backends.cpu_native import NativeAtomicI32
from .scheduler import WorkStealingScheduler, AdaptiveScheduler
from .taskgraph import TaskGraph
from .memory import MemoryPool, get_pool
from .profiler import Profiler, benchmark
from .fusion import fuse_scale_add_scalar, unfused_scale_add_scalar

__version__ = "2.3.0"
__all__ = [
    "kernel", "cascade", "launch", "submit", "dim3",
    "threadIdx", "blockIdx", "blockDim", "gridDim",
    "shared", "local", "syncthreads",
    "atomicAdd", "atomicMax", "atomicMin",
    "DeviceArray", "to_device", "to_host",
    "calculate_grid", "calculate_grid_2d",
    "Timer", "ParallelContext", "get_context",
    "map_parallel", "reduce", "scan", "shutdown",
    "NativeCPUBackend", "is_native_cpu_available", "RTLBackend",
    "NativeAtomicI32",
    "WorkStealingScheduler", "AdaptiveScheduler", "TaskGraph",
    "MemoryPool", "get_pool", "Profiler", "benchmark",
    "fuse_scale_add_scalar", "unfused_scale_add_scalar",
]
