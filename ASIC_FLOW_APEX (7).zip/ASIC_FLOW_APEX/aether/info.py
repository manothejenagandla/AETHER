"""aether info – real CPU topology and backend status"""
from .backends.cpu_native import detect_topology, is_native_cpu_available, NativeCPUBackend
from .backends.selector import list_backends

def print_info():
    print("AETHER – CPU Parallel Runtime")
    print("=" * 50)
    topo = detect_topology()
    print("CPU Topology (detected):")
    for k, v in topo.items():
        print(f"  {k}: {v}")
    print()
    print("Backends:")
    for name, info in list_backends().items():
        status = "AVAILABLE" if info["available"] else "UNAVAILABLE"
        print(f"  {name:12}: {status}  – {info['description']}")
    if is_native_cpu_available():
        be = NativeCPUBackend()
        print()
        print("Native backend info:")
        for k, v in be.info().items():
            if k != "topology":
                print(f"  {k}: {v}")

if __name__ == "__main__":
    print_info()
