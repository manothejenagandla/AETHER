"""
AETHER Work-Stealing + Adaptive Scheduler
- Real steals (demonstrable)
- Adaptive parameters that affect execution
- Integration hooks for native backend
"""

from __future__ import annotations
import threading
import time
import random
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Any, List, Optional, Deque
import os

@dataclass
class Task:
    id: int
    fn: Callable
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    result: Any = None
    exception: Optional[Exception] = None
    done: bool = False

@dataclass
class SchedulerMetrics:
    tasks_submitted: int = 0
    tasks_completed: int = 0
    tasks_stolen: int = 0
    failed_steals: int = 0
    steals_per_worker: List[int] = field(default_factory=list)

    def to_dict(self):
        return {
            "tasks_submitted": self.tasks_submitted,
            "tasks_completed": self.tasks_completed,
            "tasks_stolen": self.tasks_stolen,
            "failed_steals": self.failed_steals,
            "steals_per_worker": list(self.steals_per_worker),
        }


class WorkStealingScheduler:
    """
    Multi-worker work-stealing scheduler.
    Push strategy can force imbalance so steals are observable.
    """

    def __init__(self, n_workers: Optional[int] = None, force_imbalance: bool = False):
        self.n_workers = max(1, n_workers or (os.cpu_count() or 2))
        self.force_imbalance = force_imbalance
        self._deques: List[Deque[Task]] = [deque() for _ in range(self.n_workers)]
        self._locks = [threading.Lock() for _ in range(self.n_workers)]
        self._workers: List[threading.Thread] = []
        self._stop = threading.Event()
        self._task_id = 0
        self._task_id_lock = threading.Lock()
        self._pending = 0
        self._pending_lock = threading.Lock()
        self._done_cond = threading.Condition()
        self.metrics = SchedulerMetrics()
        self.metrics.steals_per_worker = [0] * self.n_workers
        self._started = False
        self._affinity = False

    def start(self, affinity: bool = False):
        if self._started:
            return
        self._affinity = affinity
        self._stop.clear()
        self._workers = []
        for i in range(self.n_workers):
            t = threading.Thread(target=self._worker_loop, args=(i,), daemon=True, name=f"aether-worker-{i}")
            t.start()
            self._workers.append(t)
        self._started = True

    def _next_id(self) -> int:
        with self._task_id_lock:
            self._task_id += 1
            return self._task_id

    def submit(self, fn: Callable, *args, **kwargs) -> Task:
        task = Task(id=self._next_id(), fn=fn, args=args, kwargs=kwargs)
        with self._pending_lock:
            self._pending += 1
            self.metrics.tasks_submitted += 1

        if self.force_imbalance:
            # All tasks start on worker 0 → other workers must steal
            wid = 0
        else:
            wid = task.id % self.n_workers

        with self._locks[wid]:
            self._deques[wid].append(task)
        return task

    def _pop_local(self, wid: int) -> Optional[Task]:
        with self._locks[wid]:
            if self._deques[wid]:
                return self._deques[wid].pop()
        return None

    def _steal(self, thief: int) -> Optional[Task]:
        victims = list(range(self.n_workers))
        random.shuffle(victims)
        for v in victims:
            if v == thief:
                continue
            with self._locks[v]:
                if self._deques[v]:
                    task = self._deques[v].popleft()
                    self.metrics.tasks_stolen += 1
                    self.metrics.steals_per_worker[thief] += 1
                    return task
            self.metrics.failed_steals += 1
        return None

    def _worker_loop(self, wid: int):
        if self._affinity:
            try:
                # Pin this worker to a CPU if possible
                ncpu = os.cpu_count() or 1
                cpu = wid % ncpu
                os.sched_setaffinity(0, {cpu})
            except Exception:
                pass

        while not self._stop.is_set():
            task = self._pop_local(wid)
            if task is None:
                task = self._steal(wid)
            if task is None:
                time.sleep(0.0001)
                continue
            try:
                task.result = task.fn(*task.args, **task.kwargs)
            except Exception as e:
                task.exception = e
            task.done = True
            with self._pending_lock:
                self._pending -= 1
                self.metrics.tasks_completed += 1
            with self._done_cond:
                self._done_cond.notify_all()

    def wait(self, timeout: Optional[float] = None):
        deadline = None if timeout is None else time.time() + timeout
        with self._done_cond:
            while True:
                with self._pending_lock:
                    if self._pending <= 0:
                        return
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.time()
                    if remaining <= 0:
                        raise TimeoutError("Scheduler wait timed out")
                self._done_cond.wait(timeout=0.01 if remaining is None else min(0.01, remaining))

    def shutdown(self, wait: bool = True):
        self._stop.set()
        if wait:
            for t in self._workers:
                t.join(timeout=2.0)
        self._started = False

    def run_and_measure(self, tasks: List[tuple], force_imbalance: bool = True) -> dict:
        """
        tasks: list of (fn, args, kwargs) or (fn, args)
        Returns metrics including actual steal count.
        """
        old = self.force_imbalance
        self.force_imbalance = force_imbalance
        self.start()
        for item in tasks:
            if len(item) == 2:
                fn, args = item
                self.submit(fn, *args)
            else:
                fn, args, kwargs = item
                self.submit(fn, *args, **kwargs)
        self.wait(timeout=180)
        m = self.metrics.to_dict()
        self.force_imbalance = old
        return m


class AdaptiveScheduler:
    """
    Adaptive controller that actually feeds parameters back into
    NativeCPUBackend / chunking decisions.
    """

    def __init__(self, base_workers: Optional[int] = None):
        self.base_workers = base_workers or (os.cpu_count() or 2)
        self.current_workers = self.base_workers
        self.chunk_size = 65536
        self.history: List[dict] = []

    def adapt(self, last_duration_ms: float, n_items: int) -> dict:
        old_chunk = self.chunk_size
        old_workers = self.current_workers

        if n_items > 200_000 and last_duration_ms > 100:
            # Heavy → more parallelism / smaller chunks
            self.current_workers = min(self.base_workers, self.current_workers + 1)
            self.chunk_size = max(4096, self.chunk_size // 2)
        elif n_items < 50_000 and last_duration_ms < 30:
            # Light → larger chunks, fewer workers
            self.chunk_size = min(1_000_000, self.chunk_size * 2)
            self.current_workers = max(1, self.current_workers - 1)

        changed = (self.chunk_size != old_chunk) or (self.current_workers != old_workers)
        params = self.get_params()
        self.history.append({
            "duration_ms": last_duration_ms,
            "n_items": n_items,
            **params,
            "changed": changed,
        })
        return params

    def get_params(self) -> dict:
        return {
            "chunk_size": self.chunk_size,
            "workers": self.current_workers,
        }

    def apply_to_backend(self, backend) -> None:
        """Push adaptive decisions into a NativeCPUBackend instance."""
        backend.n_threads = self.current_workers
        if hasattr(backend, "chunk_size"):
            backend.chunk_size = self.chunk_size
