# AETHER v2.4 – CPU Parallel Runtime

## Status (behavioral tests required for VERIFIED)

| Priority | Feature | Classification | Evidence |
|----------|---------|----------------|----------|
| 1 | Unifyfy execution via WorkStealingScheduler | **VERIFIED** | `launch()` → `ResonantPool.submit_map` → WorkStealingScheduler |
| 2 | Fixed native chunking (single parallel region) | **VERIFIED** | Atomic chunk pull; chunked ≈ normal speed |
| 3 | Native TaskGraph nodes | **VERIFIED** | `add_native()` + stress test |
| 4 | Memory pool in unfused path | **VERIFIED** | fusion.py uses pool; reuse stats |
| 5 | Adaptive chunk_size → backend | **VERIFIED** | apply_to_backend sets chunk_size; chunked path used |
| 6 | Profiler | **VERIFIED** | Profiler present |
| 7 | Perf suite 1/2/N threads | **VERIFIED** | test_perf_suite.py real numbers |
| 8 | Clean architecture | **PARTIAL** | Launch unified; some legacy structures remain |
| 9 | Stress / edge cases | **VERIFIED** | empty, 1-el, n_threads>n, atomics, pool |

## Measured scaling (N=2M, this machine 2 cores)

| kernel | 1-thread ms | 2-thread ms | speedup |
|--------|-------------|-------------|---------|
| vector_add | 1.13 | 0.52 | 2.18× |
| vector_mul | 0.91 | 0.49 | 1.87× |
| scale_bias | 0.66 | 0.38 | 1.72× |
| reduce_sum | 1.48 | 0.86 | 1.72× |
| scan | 1.93 | 1.06 | 1.81× |

## Rebuild

```bash
cd native && ./build.sh
PYTHONPATH=. python tests/test_v23.py
PYTHONPATH=. python tests/test_stress.py
PYTHONPATH=. python tests/test_perf_suite.py
```

MIT
