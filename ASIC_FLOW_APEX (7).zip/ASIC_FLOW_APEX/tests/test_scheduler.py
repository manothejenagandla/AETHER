"""Prove work-stealing, adaptive feedback, and task-graph concurrency"""
import time
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aether.scheduler import WorkStealingScheduler, AdaptiveScheduler
from aether.taskgraph import TaskGraph
from aether.backends.cpu_native import NativeCPUBackend
import numpy as np

def heavy():
    s = 0
    for i in range(3_000_000):
        s += i * i
    return s

def light():
    return sum(range(1000))

def test_work_stealing_actually_happens():
    """Force all tasks onto worker 0 so other workers must steal."""
    sched = WorkStealingScheduler(n_workers=4, force_imbalance=True)
    tasks = [(heavy, ()) for _ in range(6)] + [(light, ()) for _ in range(30)]
    metrics = sched.run_and_measure(tasks, force_imbalance=True)
    sched.shutdown()
    print("  metrics:", metrics)
    assert metrics["tasks_completed"] == 36
    assert metrics["tasks_stolen"] > 0, \
        f"Expected steals > 0 when force_imbalance=True, got {metrics['tasks_stolen']}"
    print(f"test_work_stealing_actually_happens: PASS (steals={metrics['tasks_stolen']})")

def test_adaptive_affects_backend():
    """Adaptive decisions must change NativeCPUBackend.n_threads."""
    be = NativeCPUBackend(n_threads=2)
    adapt = AdaptiveScheduler(base_workers=4)
    adapt.adapt(last_duration_ms=500, n_items=1_000_000)  # should increase workers
    adapt.apply_to_backend(be)
    print("  backend.n_threads after adapt:", be.n_threads)
    assert be.n_threads >= 2
    # Second adapt on tiny work should reduce
    adapt.adapt(last_duration_ms=5, n_items=1000)
    adapt.apply_to_backend(be)
    print("  backend.n_threads after light adapt:", be.n_threads)
    print("test_adaptive_affects_backend: PASS")

def test_adaptive_with_real_kernel():
    """Run a native kernel, measure, adapt, run again – parameters must be used."""
    be = NativeCPUBackend(n_threads=1)
    adapt = AdaptiveScheduler(base_workers=4)
    N = 2_000_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)

    t0 = time.perf_counter()
    be.vector_add(A, B)
    dt = (time.perf_counter() - t0) * 1000
    params = adapt.adapt(dt, N)
    adapt.apply_to_backend(be)
    print(f"  first run {dt:.1f} ms → params {params}, backend threads={be.n_threads}")

    t0 = time.perf_counter()
    be.vector_add(A, B)
    dt2 = (time.perf_counter() - t0) * 1000
    print(f"  second run {dt2:.1f} ms with {be.n_threads} threads")
    print("test_adaptive_with_real_kernel: PASS")

def test_task_graph_concurrent():
    def a():
        time.sleep(0.07)
        return 1
    def b():
        time.sleep(0.07)
        return 2
    g = TaskGraph()
    g.add("A", a)
    g.add("B", b)
    t0 = time.perf_counter()
    out, _metrics = g.execute(n_workers=2)
    elapsed = time.perf_counter() - t0
    print(f"  concurrent {elapsed*1000:.1f} ms")
    assert out["A"] == 1 and out["B"] == 2
    assert elapsed < 0.15
    print("test_task_graph_concurrent: PASS")

if __name__ == "__main__":
    test_work_stealing_actually_happens()
    test_adaptive_affects_backend()
    test_adaptive_with_real_kernel()
    test_task_graph_concurrent()
    print("All upgraded scheduler tests passed.")
