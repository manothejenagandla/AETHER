"""Stress and edge-case tests"""
import numpy as np
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aether.backends.cpu_native import NativeCPUBackend, NativeAtomicI32
from aether.taskgraph import TaskGraph
from aether.memory import MemoryPool
import threading

def test_empty_and_one():
    be = NativeCPUBackend()
    empty = np.array([], dtype=np.float32)
    assert be.vector_add(empty, empty).size == 0
    assert be.reduce_sum(empty) == 0.0
    one = np.array([3.5], dtype=np.float32)
    assert abs(be.reduce_sum(one) - 3.5) < 1e-6
    assert np.allclose(be.scale(one, 2.0), [7.0])
    print("test_empty_and_one: PASS")

def test_n_threads_gt_n():
    be = NativeCPUBackend(n_threads=64)
    A = np.arange(10, dtype=np.float32)
    B = np.ones(10, dtype=np.float32)
    C = be.vector_add(A, B)
    assert np.allclose(C, A+B)
    print("test_n_threads_gt_n: PASS")

def test_native_taskgraph_overlap():
    be = NativeCPUBackend()
    N = 500_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)
    g = TaskGraph()
    g.add_native("A", be, "vector_add", A, B)
    g.add_native("B", be, "scale", A, 2.0)
    import time
    t0 = time.perf_counter()
    results, metrics = g.execute(n_workers=2)
    elapsed = time.perf_counter() - t0
    assert "A" in results and "B" in results
    print(f"  native taskgraph elapsed={elapsed*1000:.1f} ms steals={metrics.get('tasks_stolen',0)}")
    print("test_native_taskgraph_overlap: PASS")

def test_pool_stats():
    pool = MemoryPool()
    pool.clear()
    a = pool.acquire((100,), np.float32)
    pool.release(a)
    b = pool.acquire((100,), np.float32)
    assert pool.stats["reuses"] >= 1
    print("test_pool_stats: PASS", pool.stats)

if __name__ == "__main__":
    test_empty_and_one()
    test_n_threads_gt_n()
    test_native_taskgraph_overlap()
    test_pool_stats()
    print("All stress tests PASS")
