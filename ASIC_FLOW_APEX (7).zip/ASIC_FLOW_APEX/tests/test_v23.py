"""AETHER v2.3 verification tests – prove real behavior"""
import numpy as np
import sys
import time
import threading
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aether.backends.cpu_native import NativeCPUBackend, NativeAtomicI32, is_native_cpu_available
from aether.scheduler import WorkStealingScheduler, AdaptiveScheduler
from aether.fusion import fuse_scale_add_scalar, unfused_scale_add_scalar
from aether.memory import MemoryPool

def test_chunk_size_used():
    """Adaptive chunk_size must be received and used by backend."""
    be = NativeCPUBackend(n_threads=2)
    adapt = AdaptiveScheduler(base_workers=4)
    adapt.chunk_size = 8192
    adapt.current_workers = 2
    adapt.apply_to_backend(be)
    assert be.chunk_size == 8192, f"backend.chunk_size={be.chunk_size}"
    assert be.n_threads == 2
    # Execute with chunk_size set
    A = np.random.randn(100000).astype(np.float32)
    B = np.random.randn(100000).astype(np.float32)
    C = be.vector_add(A, B)
    assert np.allclose(C, A+B, atol=1e-5)
    print("test_chunk_size_used: PASS")

def test_real_fusion():
    """Fused path = 1 launch; unfused = 2 launches; same result."""
    be = NativeCPUBackend()
    A = np.random.randn(200000).astype(np.float32)
    be.kernel_launches = 0
    fused = fuse_scale_add_scalar(be, A, 2.0, 3.0)
    fused_launches = be.kernel_launches
    be.kernel_launches = 0
    unfused = unfused_scale_add_scalar(be, A, 2.0, 3.0)
    unfused_launches = be.kernel_launches
    assert fused_launches == 1, f"fused launches={fused_launches}"
    assert unfused_launches == 2, f"unfused launches={unfused_launches}"
    assert np.allclose(fused, unfused, atol=1e-5)
    assert np.allclose(fused, A*2.0+3.0, atol=1e-5)
    print(f"test_real_fusion: PASS (fused={fused_launches} launch, unfused={unfused_launches})")

def test_atomic_stress():
    """Many workers, thousands of atomic increments – exact result."""
    counter = NativeAtomicI32(0)
    n_workers = 8
    incs_per = 5000
    def worker():
        for _ in range(incs_per):
            counter.add(1)
    threads = [threading.Thread(target=worker) for _ in range(n_workers)]
    for t in threads: t.start()
    for t in threads: t.join()
    expected = n_workers * incs_per
    got = counter.load()
    assert got == expected, f"atomic result {got} != {expected}"
    print(f"test_atomic_stress: PASS ({got} increments exact)")

def test_memory_pool_reuse():
    pool = MemoryPool()
    a = pool.acquire((1000,), np.float32)
    pool.release(a)
    b = pool.acquire((1000,), np.float32)
    assert pool.stats["reuses"] >= 1
    assert pool.stats["allocs"] == 1
    print("test_memory_pool_reuse: PASS", pool.stats)

def test_reduce_stability():
    be = NativeCPUBackend()
    # mixed signs + large range
    data = np.concatenate([
        np.random.randn(100000).astype(np.float32) * 1e3,
        np.random.randn(100000).astype(np.float32) * 1e-2,
        -np.random.rand(50000).astype(np.float32) * 1e2,
    ])
    got = be.reduce_sum(data)
    expected = float(np.sum(data.astype(np.float64)))  # higher precision ref
    rel = abs(got - expected) / max(abs(expected), 1.0)
    assert rel < 1e-4, f"rel error {rel}"
    print(f"test_reduce_stability: PASS (rel={rel:.2e})")

def test_work_stealing():
    sched = WorkStealingScheduler(n_workers=4, force_imbalance=True)
    def heavy():
        return sum(i*i for i in range(500000))
    tasks = [(heavy, ()) for _ in range(12)]
    m = sched.run_and_measure(tasks, force_imbalance=True)
    sched.shutdown()
    assert m["tasks_stolen"] > 0
    print(f"test_work_stealing: PASS (steals={m['tasks_stolen']})")

if __name__ == "__main__":
    assert is_native_cpu_available()
    test_chunk_size_used()
    test_real_fusion()
    test_atomic_stress()
    test_memory_pool_reuse()
    test_reduce_stability()
    test_work_stealing()
    print("All v2.3 verification tests PASSED.")
