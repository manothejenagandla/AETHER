"""RTL tests with isolated temp directories"""
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from aether.backends.rtl_backend import RTLBackend, SUPPORTED_KERNELS

def test_generate_vector_add():
    with tempfile.TemporaryDirectory() as td:
        be = RTLBackend(output_dir=td)
        path = be.generate("vector_add", module_name="test_vadd")
        assert path.exists()
        text = path.read_text()
        assert "module test_vadd" in text
        assert "rdata_a + rdata_b" in text
        assert "illustrative" not in text.lower()
    print("test_generate_vector_add: PASS")

def test_generate_saxpy():
    with tempfile.TemporaryDirectory() as td:
        be = RTLBackend(output_dir=td)
        path = be.generate("saxpy", module_name="test_saxpy")
        assert "module test_saxpy" in path.read_text()
    print("test_generate_saxpy: PASS")

def test_unsupported_kernel_raises():
    with tempfile.TemporaryDirectory() as td:
        be = RTLBackend(output_dir=td)
        try:
            be.generate("matrix_multiply_complex")
            assert False
        except ValueError as e:
            assert "Unsupported" in str(e)
    print("test_unsupported_kernel_raises: PASS")

def test_supported_list():
    assert "vector_add" in SUPPORTED_KERNELS
    print("test_supported_list: PASS")

if __name__ == "__main__":
    test_generate_vector_add()
    test_generate_saxpy()
    test_unsupported_kernel_raises()
    test_supported_list()
    print("All RTL tests passed.")
