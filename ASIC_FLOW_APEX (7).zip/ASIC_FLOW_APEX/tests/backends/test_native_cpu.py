"""Native CPU backend v2.0 – correctness + scan + fusion"""
import numpy as np
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from aether.backends.cpu_native import NativeCPUBackend, is_native_cpu_available, detect_topology

def test_available():
    assert is_native_cpu_available()
    print("test_available: PASS")

def test_topology():
    t = detect_topology()
    assert t["logical_cpus"] >= 1
    print("test_topology: PASS", t)

def test_vector_ops():
    be = NativeCPUBackend()
    N = 1_000_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)
    assert np.allclose(be.vector_add(A, B), A+B, atol=1e-5)
    assert np.allclose(be.vector_mul(A, B), A*B, atol=1e-5)
    print("test_vector_ops: PASS")

def test_saxpy_scale():
    be = NativeCPUBackend()
    X = np.random.randn(500_000).astype(np.float32)
    Y = np.random.randn(500_000).astype(np.float32)
    Y0 = Y.copy()
    be.saxpy(2.5, X, Y)
    assert np.allclose(Y, 2.5*X + Y0, atol=1e-5)
    assert np.allclose(be.scale(X, 3.0), X*3.0, atol=1e-5)
    print("test_saxpy_scale: PASS")

def test_fused_scale_bias():
    be = NativeCPUBackend()
    A = np.random.randn(400_000).astype(np.float32)
    out = be.scale_bias(A, 2.0, 1.5)
    expected = A * 2.0 + 1.5
    assert np.allclose(out, expected, atol=1e-5)
    print("test_fused_scale_bias: PASS")

def test_reductions():
    be = NativeCPUBackend()
    data = np.random.randn(300_000).astype(np.float32)
    assert abs(be.reduce_sum(data) - data.sum()) / max(abs(data.sum()),1) < 1e-4
    assert abs(be.reduce_max(data) - data.max()) < 1e-5
    assert abs(be.reduce_min(data) - data.min()) < 1e-5
    print("test_reductions: PASS")

def test_inclusive_scan():
    be = NativeCPUBackend()
    data = np.random.randn(50_000).astype(np.float32)
    got = be.inclusive_scan(data)
    expected = np.cumsum(data)
    # Parallel scan can have tiny FP differences
    assert np.allclose(got, expected, atol=1e-3, rtol=1e-4)
    print("test_inclusive_scan: PASS")

def test_exclusive_scan():
    be = NativeCPUBackend()
    data = np.array([1,2,3,4,5], dtype=np.float32)
    got = be.exclusive_scan(data)
    # exclusive: [0,1,3,6,10]
    expected = np.array([0,1,3,6,10], dtype=np.float32)
    assert np.allclose(got, expected, atol=1e-5)
    print("test_exclusive_scan: PASS")

def test_scaling():
    be1 = NativeCPUBackend(n_threads=1)
    beN = NativeCPUBackend()
    N = 5_000_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)
    t0 = time.perf_counter(); be1.vector_add(A,B); t1=time.perf_counter()
    mono = t1-t0
    t0 = time.perf_counter(); beN.vector_add(A,B); t1=time.perf_counter()
    multi = t1-t0
    print(f"  1-thread {mono*1000:.1f}ms | {beN.n_threads}-thread {multi*1000:.1f}ms | speedup {mono/multi if multi>0 else 0:.2f}x")
    print("test_scaling: PASS")

if __name__ == "__main__":
    test_available()
    test_topology()
    test_vector_ops()
    test_saxpy_scale()
    test_fused_scale_bias()
    test_reductions()
    test_inclusive_scan()
    test_exclusive_scan()
    test_scaling()
    print("All native CPU v2.0 tests passed.")
