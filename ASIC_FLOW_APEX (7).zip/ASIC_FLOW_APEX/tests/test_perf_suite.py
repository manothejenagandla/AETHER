"""CPU performance suite – 1/2/N threads, honest numbers"""
import numpy as np
import time
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aether.backends.cpu_native import NativeCPUBackend

def bench(fn, warmup=1, reps=3):
    for _ in range(warmup):
        fn()
    samples = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - t0) * 1000)
    return sum(samples) / len(samples)

def run_suite():
    N = 2_000_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)
    max_t = NativeCPUBackend().n_threads
    thread_counts = sorted(set([1, 2, max_t]))
    print(f"N={N:,}  thread_counts={thread_counts}")
    print(f"{'kernel':<14} {'threads':>7} {'ms':>10} {'speedup':>8} {'eff':>6}")
    results = {}
    for name, make_fn in [
        ("vector_add", lambda be: lambda: be.vector_add(A, B)),
        ("vector_mul", lambda be: lambda: be.vector_mul(A, B)),
        ("saxpy", lambda be: lambda: be.saxpy(2.5, A, B.copy())),
        ("scale_bias", lambda be: lambda: be.scale_bias(A, 2.0, 1.0)),
        ("reduce_sum", lambda be: lambda: be.reduce_sum(A)),
        ("incl_scan", lambda be: lambda: be.inclusive_scan(A)),
    ]:
        base = None
        for nt in thread_counts:
            be = NativeCPUBackend(n_threads=nt)
            ms = bench(make_fn(be))
            if base is None:
                base = ms
            speedup = base / ms if ms > 0 else 0
            eff = speedup / nt if nt else 0
            print(f"{name:<14} {nt:>7} {ms:>10.2f} {speedup:>8.2f} {eff:>6.2f}")
            results[(name, nt)] = {"ms": ms, "speedup": speedup, "eff": eff}
    # Chunked vs normal
    print("\nChunked comparison (vector_add):")
    be = NativeCPUBackend(n_threads=max_t)
    ms_norm = bench(lambda: be.vector_add(A, B))
    be.chunk_size = 65536
    ms_chunk = bench(lambda: be.vector_add(A, B))
    print(f"  normal:  {ms_norm:.2f} ms")
    print(f"  chunked: {ms_chunk:.2f} ms  (chunk_size=65536)")
    return results

if __name__ == "__main__":
    run_suite()
    print("test_perf_suite: PASS (measurements recorded)")
