"""Tests for AETHER / ASIC FLOW Apex"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import (
    kernel, launch, cascade, submit, calculate_grid,
    to_device, to_host, map_parallel, reduce,
    threadIdx, blockIdx, blockDim
)

@kernel
def add_one(a, b, n):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        b[i] = a[i] + 1.0

def test_basic():
    N = 50_000
    a = to_device(np.ones(N, dtype=np.float32))
    b = to_device(np.zeros(N, dtype=np.float32))
    block = 256
    launch(add_one, calculate_grid(N, block), block, a, b, N)
    assert np.allclose(to_host(b), 2.0)
    print("test_basic: PASS")

def test_cascade():
    N = 30_000
    a = to_device(np.ones(N, dtype=np.float32))
    t = to_device(np.zeros(N, dtype=np.float32))
    r = to_device(np.zeros(N, dtype=np.float32))
    block = 128

    @kernel
    def mul2(inp, out, n):
        i = blockIdx.x * blockDim.x + threadIdx.x
        if i < n: out[i] = inp[i] * 2

    @kernel
    def add3(inp, out, n):
        i = blockIdx.x * blockDim.x + threadIdx.x
        if i < n: out[i] = inp[i] + 3

    pipe = (cascade("t")
            .then(mul2, calculate_grid(N, block), block, a, t, N)
            .then(add3, calculate_grid(N, block), block, t, r, N))
    submit(pipe)
    assert np.allclose(to_host(r), 5.0)
    print("test_cascade: PASS")

def test_reduce():
    data = np.arange(10000, dtype=np.float64)
    s = reduce(data, op="sum")
    assert abs(s - data.sum()) < 1e-6
    print("test_reduce: PASS")

def test_map():
    data = np.arange(5000, dtype=np.float64)
    out = map_parallel(lambda x: x * 2, data)
    assert np.allclose(out, data * 2)
    print("test_map: PASS")

if __name__ == "__main__":
    test_basic()
    test_cascade()
    test_reduce()
    test_map()
    print("All Apex tests passed.")
