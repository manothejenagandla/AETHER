"""AETHER – Parallel histogram with atomics"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import (
    kernel, launch, calculate_grid, atomicAdd,
    to_device, to_host, threadIdx, blockIdx, blockDim
)

@kernel
def hist_kernel(data, hist, n, bins):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        v = float(data[i])
        b = int(v * bins)
        if b >= bins: b = bins - 1
        if b < 0: b = 0
        atomicAdd(hist, b, 1)

def main():
    N = 300_000
    BINS = 12
    print(f"AETHER – Atomic Histogram  N={N:,}  bins={BINS}")

    data = np.random.rand(N).astype(np.float32)
    hist = to_device(np.zeros(BINS, dtype=np.int32))

    launch(hist_kernel, calculate_grid(N), 256,
           to_device(data), hist, N, BINS, timed=True)

    got = to_host(hist)
    exp = np.histogram(data, bins=BINS, range=(0,1))[0]
    print("Got :", got)
    print("Exp :", exp)
    print("PASS" if np.array_equal(got, exp) else "FAIL")

if __name__ == "__main__":
    main()
