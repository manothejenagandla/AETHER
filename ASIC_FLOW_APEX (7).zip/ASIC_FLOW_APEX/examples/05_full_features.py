"""AETHER full feature demo (CPU-only)"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import (
    kernel, cascade, launch, submit, calculate_grid,
    to_device, to_host, shared, syncthreads,
    map_parallel, reduce,
    threadIdx, blockIdx, blockDim,
)
from aether.backends import NativeCPUBackend, RTLBackend
from aether.scheduler import WorkStealingScheduler, AdaptiveScheduler
from aether.profiler import Profiler, benchmark

def main():
    print("=== AETHER Full Feature Demo (CPU) ===\n")

    # Native backend
    be = NativeCPUBackend()
    print("Native info:", be.info())

    N = 500_000
    A = np.random.randn(N).astype(np.float32)
    B = np.random.randn(N).astype(np.float32)

    C = be.vector_add(A, B)
    print("vector_add max err:", np.max(np.abs(C - (A+B))))

    out = be.scale_bias(A, 2.0, 1.0)
    print("scale_bias max err:", np.max(np.abs(out - (A*2+1))))

    print("reduce_sum:", be.reduce_sum(A))
    print("inclusive_scan sample:", be.inclusive_scan(np.array([1,2,3,4], dtype=np.float32)))

    # Adaptive
    adapt = AdaptiveScheduler()
    adapt.adapt(200, N)
    adapt.apply_to_backend(be)
    print("Adaptive workers:", be.n_threads)

    # Work stealing demo
    sched = WorkStealingScheduler(n_workers=4, force_imbalance=True)
    def work():
        return sum(range(10000))
    metrics = sched.run_and_measure([(work, ()) for _ in range(20)], force_imbalance=True)
    sched.shutdown()
    print("Steals:", metrics["tasks_stolen"])

    # RTL
    rtl = RTLBackend(output_dir="/tmp/aether_rtl_demo")
    path = rtl.generate("vector_add", module_name="demo_vadd")
    print("RTL generated:", path)

    # Profiler
    prof = Profiler()
    with prof.measure("native_add"):
        be.vector_add(A, B)
    prof.print_report()

    print("\n=== Demo finished ===")

if __name__ == "__main__":
    main()
