"""
AETHER – Cascade Kernels (novel construct)
A multi-stage pipeline that the runtime executes as a single logical unit.
This style of automatic cascade does not exist in classic CUDA / OpenMP.
"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import (
    kernel, cascade, submit, calculate_grid,
    to_device, to_host, threadIdx, blockIdx, blockDim
)

@kernel
def stage_scale(inp, out, n, factor):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        out[i] = inp[i] * factor

@kernel
def stage_add_const(inp, out, n, const):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        out[i] = inp[i] + const

@kernel
def stage_square(inp, out, n):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        out[i] = inp[i] * inp[i]

def main():
    N = 1_500_000
    print(f"AETHER – Cascade Pipeline  N={N:,}")

    data = to_device(np.random.randn(N).astype(np.float32))
    tmp1 = to_device(np.zeros(N, dtype=np.float32))
    tmp2 = to_device(np.zeros(N, dtype=np.float32))
    result = to_device(np.zeros(N, dtype=np.float32))

    grid = calculate_grid(N)
    block = 256

    # Build a 3-stage cascade: scale → add → square
    pipe = (cascade("scale-add-square")
            .then(stage_scale,     grid, block, data, tmp1, N, 3.0)
            .then(stage_add_const, grid, block, tmp1, tmp2, N, 1.5)
            .then(stage_square,    grid, block, tmp2, result, N))

    print(f"Cascade has {len(pipe)} stages")
    submit(pipe, timed=True)

    # Verify: ((x*3) + 1.5)²
    host = to_host(data)
    expected = ((host * 3.0) + 1.5) ** 2
    err = np.max(np.abs(to_host(result) - expected))
    print(f"Max error: {err:.2e}  →  {'PASS' if err < 1e-4 else 'FAIL'}")

if __name__ == "__main__":
    main()
