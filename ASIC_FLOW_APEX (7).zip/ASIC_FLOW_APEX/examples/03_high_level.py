"""AETHER – High-level parallel patterns (map / reduce)"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import map_parallel, reduce, Timer

def main():
    N = 2_000_000
    data = np.random.randn(N).astype(np.float64)

    print("AETHER – High-level map + reduce")

    with Timer("map_parallel (square)"):
        squared = map_parallel(lambda x: x * x, data)

    with Timer("reduce sum"):
        s = reduce(squared, op="sum")

    with Timer("reduce max"):
        m = reduce(data, op="max")

    print(f"Sum of squares ≈ {s:.4f}")
    print(f"Max value      ≈ {m:.4f}")
    print("PASS")

if __name__ == "__main__":
    main()
