"""AETHER – Classic data-parallel kernel (still fully supported)"""
import numpy as np
import sys
sys.path.insert(0, "..")

from aether import kernel, launch, calculate_grid, to_device, to_host, threadIdx, blockIdx, blockDim

@kernel
def saxpy(a, x, y, n):
    i = blockIdx.x * blockDim.x + threadIdx.x
    if i < n:
        y[i] = a * x[i] + y[i]

def main():
    N = 3_000_000
    print(f"AETHER – SAXPY  N={N:,}")
    x = to_device(np.random.randn(N).astype(np.float32))
    y = to_device(np.random.randn(N).astype(np.float32))
    y_orig = to_host(y)

    launch(saxpy, calculate_grid(N), 256, 2.5, x, y, N, timed=True)

    err = np.max(np.abs(to_host(y) - (2.5 * to_host(x) + y_orig)))
    print(f"Max error: {err:.2e}  →  {'PASS' if err < 1e-5 else 'FAIL'}")

if __name__ == "__main__":
    main()
