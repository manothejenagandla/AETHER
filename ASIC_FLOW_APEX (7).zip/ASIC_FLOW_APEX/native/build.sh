#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "Building AETHER native CPU backend..."
FLAGS=""
ISA="baseline"

# Detect AVX2
if grep -q avx2 /proc/cpuinfo 2>/dev/null; then
  if g++ -O3 -shared -fPIC -std=c++17 -fopenmp -mavx2 -mfma cpu_backend.cpp -o libaether_cpu.so 2>/dev/null; then
    FLAGS="OpenMP+AVX2+FMA"
    ISA="avx2"
    echo "Built with OpenMP + AVX2 + FMA"
  fi
fi

if [ ! -f libaether_cpu.so ]; then
  if g++ -O3 -shared -fPIC -std=c++17 -fopenmp cpu_backend.cpp -o libaether_cpu.so 2>/dev/null; then
    FLAGS="OpenMP"
    ISA="sse/baseline"
    echo "Built with OpenMP (portable)"
  else
    g++ -O3 -shared -fPIC -std=c++17 cpu_backend.cpp -o libaether_cpu.so
    FLAGS="std::thread"
    ISA="baseline"
    echo "Built with std::thread fallback"
  fi
fi

echo "ISA=$ISA FLAGS=$FLAGS" > build_info.txt
ls -la libaether_cpu.so
cat build_info.txt
