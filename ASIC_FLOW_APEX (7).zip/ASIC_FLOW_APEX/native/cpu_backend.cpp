/*
 * AETHER Native CPU Backend v2.3
 * Proper atomics, hierarchical reduce with compensated accumulation option,
 * chunk_size-aware partitioning.
 */

#include <cstdint>
#include <cstring>
#include <vector>
#include <thread>
#include <algorithm>
#include <cmath>
#include <limits>
#include <atomic>
#include <cstdlib>

#ifdef _OPENMP
#include <omp.h>
#define HAS_OPENMP 1
#else
#define HAS_OPENMP 0
#endif

static int clamp_threads(int n) {
    if (n <= 0) n = (int)std::thread::hardware_concurrency();
    return n < 1 ? 1 : n;
}

// Use explicit atomic storage – never reinterpret plain int32_t* as atomic*
struct AtomicI32 {
    std::atomic<int32_t> v;
};
struct AtomicU32 {
    std::atomic<uint32_t> v;
};

extern "C" {

void aether_cpu_vector_add_f32(const float* A, const float* B, float* C, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) C[i] = A[i] + B[i];
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s;i<e;++i) C[i]=A[i]+B[i]; });
    }
    for (auto& t : ths) t.join();
#endif
}

void aether_cpu_vector_mul_f32(const float* A, const float* B, float* C, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) C[i] = A[i] * B[i];
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s;i<e;++i) C[i]=A[i]*B[i]; });
    }
    for (auto& t : ths) t.join();
#endif
}

void aether_cpu_saxpy_f32(float a, const float* X, float* Y, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) Y[i] = a * X[i] + Y[i];
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s;i<e;++i) Y[i]=a*X[i]+Y[i]; });
    }
    for (auto& t : ths) t.join();
#endif
}

void aether_cpu_scale_f32(const float* In, float* Out, float f, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) Out[i] = In[i] * f;
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s;i<e;++i) Out[i]=In[i]*f; });
    }
    for (auto& t : ths) t.join();
#endif
}

void aether_cpu_add_scalar_f32(const float* In, float* Out, float s, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) Out[i] = In[i] + s;
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s0 = t*chunk, e = std::min(s0+chunk, n); if (s0 >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s0;i<e;++i) Out[i]=In[i]+s; });
    }
    for (auto& t : ths) t.join();
#endif
}

void aether_cpu_scale_bias_f32(const float* A, float* Out, float scale, float bias, int64_t n, int n_threads) {
    if (n <= 0) return; n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) Out[i] = A[i] * scale + bias;
#else
    std::vector<std::thread> ths; int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([=](){ for(int64_t i=s;i<e;++i) Out[i]=A[i]*scale+bias; });
    }
    for (auto& t : ths) t.join();
#endif
}

// Chunk-size aware vector_add: ONE parallel region; workers pull chunks via atomic counter
void aether_cpu_vector_add_f32_chunked(const float* A, const float* B, float* C,
                                       int64_t n, int n_threads, int64_t chunk_size) {
    if (n <= 0) return;
    n_threads = clamp_threads(n_threads);
    if (chunk_size <= 0) chunk_size = (n + n_threads - 1) / n_threads;
    std::atomic<int64_t> next{0};
#if HAS_OPENMP
    #pragma omp parallel num_threads(n_threads)
    {
        while (true) {
            int64_t base = next.fetch_add(chunk_size, std::memory_order_relaxed);
            if (base >= n) break;
            int64_t end = std::min(base + chunk_size, n);
            for (int64_t i = base; i < end; ++i)
                C[i] = A[i] + B[i];
        }
    }
#else
    std::vector<std::thread> ths;
    for (int t = 0; t < n_threads; ++t) {
        ths.emplace_back([&]() {
            while (true) {
                int64_t base = next.fetch_add(chunk_size, std::memory_order_relaxed);
                if (base >= n) break;
                int64_t end = std::min(base + chunk_size, n);
                for (int64_t i = base; i < end; ++i)
                    C[i] = A[i] + B[i];
            }
        });
    }
    for (auto& th : ths) th.join();
#endif
}

// Hierarchical reduce with pairwise tree for better numerical stability
float aether_cpu_reduce_sum_f32(const float* data, int64_t n, int n_threads) {
    if (n <= 0) return 0.0f;
    n_threads = clamp_threads(n_threads);
    // Use double accumulators for partials to reduce FP error
    std::vector<double> partial(n_threads, 0.0);
    std::vector<std::thread> ths;
    int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t * chunk, e = std::min(s + chunk, n);
        if (s >= n) break;
        ths.emplace_back([&, t, s, e]() {
            double sum = 0.0;
            for (int64_t i = s; i < e; ++i) sum += (double)data[i];
            partial[t] = sum;
        });
    }
    for (auto& t : ths) t.join();
    // Pairwise tree reduction of partials
    int m = n_threads;
    while (m > 1) {
        int half = (m + 1) / 2;
        for (int i = 0; i < m / 2; ++i)
            partial[i] = partial[i] + partial[i + half];
        m = half;
    }
    return (float)partial[0];
}

float aether_cpu_reduce_max_f32(const float* data, int64_t n, int n_threads) {
    if (n <= 0) return -std::numeric_limits<float>::infinity();
    n_threads = clamp_threads(n_threads);
    std::vector<float> partial(n_threads, -std::numeric_limits<float>::infinity());
    std::vector<std::thread> ths;
    int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([&,t,s,e](){ float m=-std::numeric_limits<float>::infinity(); for(int64_t i=s;i<e;++i) if(data[i]>m) m=data[i]; partial[t]=m; });
    }
    for (auto& t : ths) t.join();
    float m = partial[0];
    for (float v : partial) if (v > m) m = v;
    return m;
}

float aether_cpu_reduce_min_f32(const float* data, int64_t n, int n_threads) {
    if (n <= 0) return std::numeric_limits<float>::infinity();
    n_threads = clamp_threads(n_threads);
    std::vector<float> partial(n_threads, std::numeric_limits<float>::infinity());
    std::vector<std::thread> ths;
    int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t*chunk, e = std::min(s+chunk, n); if (s >= n) break;
        ths.emplace_back([&,t,s,e](){ float m=std::numeric_limits<float>::infinity(); for(int64_t i=s;i<e;++i) if(data[i]<m) m=data[i]; partial[t]=m; });
    }
    for (auto& t : ths) t.join();
    float m = partial[0];
    for (float v : partial) if (v < m) m = v;
    return m;
}

void aether_cpu_inclusive_scan_f32(const float* in, float* out, int64_t n, int n_threads) {
    if (n <= 0) return;
    n_threads = clamp_threads(n_threads);
    if (n_threads > n) n_threads = (int)n;
    std::vector<float> block_sums(n_threads, 0.0f);
    std::vector<std::thread> ths;
    int64_t chunk = (n + n_threads - 1) / n_threads;
    for (int t = 0; t < n_threads; ++t) {
        int64_t s = t * chunk, e = std::min(s + chunk, n);
        if (s >= n) break;
        ths.emplace_back([&, t, s, e]() {
            float running = 0.0f;
            for (int64_t i = s; i < e; ++i) { running += in[i]; out[i] = running; }
            block_sums[t] = running;
        });
    }
    for (auto& t : ths) t.join();
    std::vector<float> offsets(n_threads, 0.0f);
    float acc = 0.0f;
    for (int t = 0; t < n_threads; ++t) { offsets[t] = acc; acc += block_sums[t]; }
    ths.clear();
    for (int t = 1; t < n_threads; ++t) {
        int64_t s = t * chunk, e = std::min(s + chunk, n);
        if (s >= n) break;
        float off = offsets[t];
        ths.emplace_back([=, &out]() { for (int64_t i = s; i < e; ++i) out[i] += off; });
    }
    for (auto& t : ths) t.join();
}

void aether_cpu_exclusive_scan_f32(const float* in, float* out, int64_t n, int n_threads) {
    if (n <= 0) return;
    aether_cpu_inclusive_scan_f32(in, out, n, n_threads);
    n_threads = clamp_threads(n_threads);
#if HAS_OPENMP
    #pragma omp parallel for num_threads(n_threads) schedule(static)
    for (int64_t i = 0; i < n; ++i) out[i] = out[i] - in[i];
#else
    for (int64_t i = 0; i < n; ++i) out[i] = out[i] - in[i];
#endif
}

// Proper atomics using dedicated atomic objects allocated by the runtime
AtomicI32* aether_cpu_atomic_i32_create(int32_t initial) {
    auto* p = new AtomicI32();
    p->v.store(initial, std::memory_order_relaxed);
    return p;
}
void aether_cpu_atomic_i32_destroy(AtomicI32* p) { delete p; }
int32_t aether_cpu_atomic_i32_add(AtomicI32* p, int32_t v) {
    return p->v.fetch_add(v, std::memory_order_relaxed);
}
int32_t aether_cpu_atomic_i32_load(AtomicI32* p) {
    return p->v.load(std::memory_order_relaxed);
}

AtomicU32* aether_cpu_atomic_u32_create(uint32_t initial) {
    auto* p = new AtomicU32();
    p->v.store(initial, std::memory_order_relaxed);
    return p;
}
void aether_cpu_atomic_u32_destroy(AtomicU32* p) { delete p; }
// float atomic add via CAS on bit pattern stored in AtomicU32
void aether_cpu_atomic_f32_add(AtomicU32* p, float value) {
    uint32_t old_bits = p->v.load(std::memory_order_relaxed);
    while (true) {
        float old_val; std::memcpy(&old_val, &old_bits, 4);
        float new_val = old_val + value;
        uint32_t new_bits; std::memcpy(&new_bits, &new_val, 4);
        if (p->v.compare_exchange_weak(old_bits, new_bits, std::memory_order_relaxed))
            break;
    }
}
float aether_cpu_atomic_f32_load(AtomicU32* p) {
    uint32_t bits = p->v.load(std::memory_order_relaxed);
    float v; std::memcpy(&v, &bits, 4);
    return v;
}

void* aether_cpu_aligned_alloc(int64_t nbytes, int64_t align) {
    if (align < 64) align = 64;
    void* p = nullptr;
    if (posix_memalign(&p, (size_t)align, (size_t)nbytes) != 0) p = nullptr;
    return p;
}
void aether_cpu_aligned_free(void* p) { free(p); }

int aether_cpu_hardware_concurrency() { return (int)std::thread::hardware_concurrency(); }
int aether_cpu_has_openmp() { return HAS_OPENMP; }

} // extern "C"
